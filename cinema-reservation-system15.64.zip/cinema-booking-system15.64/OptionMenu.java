import java.util.*;
/**
 * An optionMenu class
 * the class prints out a menu
 * 
 * @author Willem Hoogsteen
 * @version 1.1 2020.02.02
 */
public class OptionMenu{
 
    /**
     * print out of the optionmenu.
     */
    public void printOptionMenu()
    {                    
                    System.out.println("------------------------------------");
                    System.out.println(":Cinema SeatReservation System by Willem Hoogsteen:");
                    System.out.println("------------------------------------\n");
                    System.out.println("Please Enter 1 to Add Theatre");
                    System.out.println("Please Enter 2 to Add SeatPlan");
                    System.out.println("Please Enter 3 to Add Show");
                    System.out.println("Please Enter 4 to Display Shows");
                    System.out.println("Please Enter 5 to Make SeatReservation");
                    System.out.println("Please Enter 6 to Cancel SeatReservation");
                    System.out.println("Please Enter 7 to Exit\n");                                                         
                    System.out.print("Enter Option: ");
    }
}