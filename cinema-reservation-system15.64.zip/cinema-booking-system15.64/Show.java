import java.util.*;
/**
 * A Class that delivers information about the theatres and free/reserved seats.
 * 
 * The class creates rows in an ArrayList for the seatplan use.
 * 
 * @author Willem Hoogsteen
 * @version 1.1 2020.02.02
 */
public class Show {
    private int showNumber;//unique shownumber
    private String showName;// the showname
    private String showDate;// the date of the show
    private Theatre theatre;// the theatre
    public ArrayList<Seat> seats;//collection of seats
    private int freeSeats;// free seatcounter of the seat collection

    //these came over from theatre
    private int rowCount;// rowcounter
    public ArrayList<Row> rows;// collection of rows in a show Object
    
    //came over from row
    private int seatCount;// the seatnumber
    private int rowNumber; // the rowNumber
    
    //these i added
    private Show show;//the show
    private SeatPlan seatPlan;// the seatPlan of the show   
    int seatPlanNumber;// the seatplannumber
    /**
     * Constructor
     * @param showName The showname  of a show
     * @param showDate The showdate  of a show
     * @param Theatre theatre The theatre of the show
     * @param showNumber The unique shownumber  of a show
     * creates ArrayList rows
     */
    public Show(String showName, String showDate, SeatPlan seatPlan, Theatre theatre,
    int showNumber, int seatPlanNumber)
    {                
        this.showName = showName;
        this.showDate = showDate;
        this.seatPlan = seatPlan;
        this.seatPlanNumber = seatPlanNumber;
        this.theatre = theatre;
        this.showNumber = showNumber;
        
        rows = new ArrayList<Row>();
    }

    /**
     * load the seats in a row of the theatre's seatplan
     */
    
    public void loadSeats()
    {
        for (Row row : show.getRows()) 
        {
            for (Seat seat : row.getSeats())
            {
                row.seats.add(seat);
            }
        }
        
    }
    
    /**
     * show the free seats available in a show/theatre seatplan
     */
    public int getFreeSeatsCount()
    {
        for (Seat seat : seats) 
        {
            if (!seat.getReservationStatus())
            {
                freeSeats++;
            }
        }
        return freeSeats;
    }
    
    /**
     * sets the shownumber for a movie.
     * @param showNumber The showNumber of the movie.
     */
    public void setShowNumber(int showNumber)
    {
        this.showNumber = showNumber;
    }
    
    /**
     * sets the showname for a movie.
     * @param showName The showName of the movie.
     */
    public void setShowName(String showName)
    {
        this.showName = showName;
    }
        
    /**
     * sets the showdate for a movie.
     * @param showDate The showDate of the movie.
     */
    public void setShowDate(String showDate)
    {
        this.showDate = showDate;
    }
    
    /**
     * sets the theatre for a movie.
     * @param Theatre theatre The theatre showing the movie.
     */
    public void setTheatre(Theatre theatre)
    {
        this.theatre = theatre;
    }
    
    /**
     * Return shownumber
     * @return showNumber The showNumber of the movie.
     */
    public int getShowNumber()
    {
        return showNumber;
    }
    
    /**
     * Return showName
     * @return showname The showname of a movie
     */
    public String getShowName()
    {
        return showName;
    }
    
    /**
     * Return showDate
     * @return showdate The showdate of a movie
     */
    public String getShowDate()
    {
        return showDate;
    }
    
    /**
     * Return theatre
     * @return theatre The theatre showing the movie
     */
    public Theatre getTheatre()
    {
        return theatre;
    }

    /**
     * Set the show.
     * @param Show show The show showing the movie.
     */
    public void setShow(Show show)
    {
        this.show = show;
    }
    
    /**
     * sets the seatPlan for a movie.
     * @param SeatPlan seatPlan The seatPlan of a theatre showing the movie.
     */
    public void setSeatPlan(SeatPlan seatPlan)
    {
        this.seatPlan = seatPlan;
    }
    
    /**
     * Return the show.
     * @return show The show showing the movie
     */
    public Show getShow()
    {
        return show;
    }

    /**
     * Return seatPlan
     * @return seatPlan The seatPlan for the movie
     */
    public SeatPlan getSeatPlan()
    {
        return seatPlan;
    }
   
    /**
     * Return seatPlanNumber
     * @return seatPlanNumber The seatPlanNumber showing the movie
     */
    public int getSeatPlanNumber()
    {
        return seatPlanNumber;
    }
    
    /**
     * Return a list of all rows
     * @return rows The ArrayList collection of rows
     */
    public ArrayList<Row> getRows()
    {
        return rows;
    }
    
    /**
     * create rows for a seatplan
     * @param rowClass  A classnumber for price differentiation
     * @param seatCount The number of seats in a row
     * @param rowCount  The number of rows
     * @param rowPositionCounter (starts at 1) The row position for the next range of rows
     */
    public void createRows(int rowClass, int seatCount, int rowCount, int rowPositionCounter)
    {
        // rowPositionCounter is equal to rowNumber
        for (int i = rowPositionCounter; i < (rowCount+rowPositionCounter); i++)
        {
            rows.add(new Row(rowClass, seatCount, i));
        }
        this.rowCount += rowCount;//this looks like its not needed at all
    
    }    
    
    /**
     * printout on screen of the seatplan connected to a show(not theatre)
     * 
     */
     public void printSeatPlan()
    {
        System.out.println();
        int maxSeatsInRow = 0;
        for (Row row : getRows())
        {
            if (row.getSeats().size() > maxSeatsInRow)
            {
                maxSeatsInRow = row.getSeats().size();
            }        
        }
        System.out.print("   |");
        for (int i=1; i <= maxSeatsInRow; i++)
        {
            if(i==1){System.out.print(" " + i);}
            if(i<10&&i>1){System.out.print("  " + i);}
            if(i>9){System.out.print(" " + i);}
        }
        System.out.print("\n");
        System.out.print("---|");
        for (int i=1; i <= maxSeatsInRow; i++)
        {
            if (i>9) {
                System.out.print("---");
            }
            else {
                System.out.print("---");
            }
        }
        System.out.print("\n");
        for (Row row : getRows())
        {
            if (row.getRowNumber()>9) {
                System.out.print(row.getRowNumber() + " | ");
            }
            else {
                System.out.print(row.getRowNumber() + "  | ");
            }
            for (Seat seat : row.getSeats())
            {
                
                if (seat.getReservationStatus()) {
                    if(seat.getSeatNumber()<9){System.out.print("X  ");}
                    if(seat.getSeatNumber()==9){System.out.print("X ");}
                     if(seat.getSeatNumber()>9){System.out.print(" X ");}
                }
                else {
                    if(seat.getSeatNumber()<9){System.out.print(seat.getSeatNumber() + "  ");}
                    if(seat.getSeatNumber()>=9){System.out.print(seat.getSeatNumber() + " ");}
                }
            }
            System.out.print("\n");
        }
        System.out.print("\n");
    }

}