import java.util.Scanner;
import java.util.InputMismatchException;
/**
 * Write a description of class InputReader here.
 *
 * @author (Willem Hoogsteen)
 * @version (1.1 2020.02.02)
 */
public class InputStringReader
{
    // instance variables - replace the example below with your own    
    private String option;       
    private Scanner choice;
    /**
     * Constructor for objects of class InputReader
     * @param option The option
     */
    public InputStringReader(String option)
    {
        // initialise instance variables
        this.option=option;    
        choice = new Scanner(System.in); // the scanner for input     
        
    }        

    /**
     * Return the option entered
     * @return option The entered option
     */
    public String getStringInput()
    {
                option =null;   
   
          try{    
                if(choice.hasNextLine()){
                System.out.print("> ");// print prompt                                                                               
                option = choice.nextLine();                
                }                           
              }
                catch (NumberFormatException nfe)
                {   
                  System.out.println("NumberFormatException in getStringInput method: " + nfe.getMessage());                  
                }
                //System.out.println(option + " deze is de return" );   
                choice.close();// close the scanner
                return option;
                
    }      
}
