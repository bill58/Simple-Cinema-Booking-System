/**
 *This class starts up a new CinemaBookingSystem.
 *
 *Author (Willem Hoogsteen)
 *@version 2019.12.17
 */
public class CinemaMain
{ 
/**
 * codeprogram starter
 * starts a cinemaReservationSystem
 * 
 */
public static void main(String[]args)
    { try
        {   CinemaReservationSystem cinemaReservationSystem = new CinemaReservationSystem();
            cinemaReservationSystem.startCinemaSystemOptionMenu();
            
        }
      
      catch (Exception e)
    {
        e.printStackTrace ();
    }
      }
    }