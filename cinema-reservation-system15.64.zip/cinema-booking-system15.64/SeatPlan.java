import java.util.*;
/**
 * Write a description of class SeatPlan here.
 *
 * @author (Willem Hoogsteen)
 * @version (1.1 2020.02.02)
 */
public class SeatPlan
{
    private int seatPlanNumber;
    private String seatPlanDescription;

    /**
     * Constructor for objects of class SaetPlan
     */
    public SeatPlan(int seatPlanNumber, String seatPlanDescription)
    {
        // initialise instance variables
        this.seatPlanNumber = seatPlanNumber;
        this.seatPlanDescription = seatPlanDescription;        
        
    }
    
    /**
     * Return seatPlanNumber
     * @return seatPlanNumber The seatPlanNumber for the movie show
     */
    public int getSeatPlanNumber()
    {
        return seatPlanNumber;
    }    

    /**
     * Return a description of the theatre
     * @return description The description of the theatre.
     */
    public String getSeatPlanDescription()
    {
        return seatPlanDescription;
    }    
    
    
    
    
}
