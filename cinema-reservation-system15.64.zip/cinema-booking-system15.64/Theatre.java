import java.util.*;
/**
 * A Class that creates a theatre object without a seatplan this seatplan is moved to Show
 * for a better reservationsystem to avoid use of same theatre seatplans
 * 
 * 
 * @author Willem Hoogsteen
 * @version 1.1 2020.02.02
 */
public class Theatre {

    private int theatreNumber;
    private String description;

    /**
     * Constructor
     * param theatreNumber The number of the theatre.
     * param  description The description e.g. "Cinema 1" of the theatre
     */
    public Theatre (int theatreNumber, String description)
    {
        this.description = description;
        this.theatreNumber = theatreNumber;
        
    }
        
    /**
     * Return a description of the theatre
     * @return description The description of the theatre.
     */
    public String getDescription()
    {
        return description;
    }
    
    /**
     * Return a number of the theatre
     * @return theatreNumber The theatreNumber of the theatre.
     */
    public int getTheatreNumber()
    {
        return theatreNumber;
    }

}