import java.util.Scanner;
import java.util.InputMismatchException;
/**
 * Write a description of class InputReader here.
 *
 * @author (Willem Hoogsteen)
 * @version (1.1 2020.02.02)
 */
public class InputIntReader
{
    // instance variables - replace the example below with your own
    int number;         
    private Scanner choice;
    /**
     * Constructor for objects of class InputReader
     * @param number The entered number as input.
     */
    public InputIntReader(int number)
    {
        // initialise instance variables
        this.number = number;
        choice = new Scanner(System.in);// open a scanner for input
    }           
    
    /**
     * Return number
     * @return number The number entered in the scanner
     */
    public int getIntInput()
    {                                          
         try{                
                if(choice.hasNextInt()){
                System.out.print("> ");// print prompt 
                number =0;
                number = choice.nextInt();                               
                                        }                
             }
                catch(InputMismatchException e)
                {
                  System.out.println("You have entered a non numeric field value");
                }          
                choice.close();// close the scanner
                return number;                            
    }    
}