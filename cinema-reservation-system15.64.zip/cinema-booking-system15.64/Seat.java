/**
 * This class accepts/cancels seat reservations.
 * keeps track of status free/reserved.
 * each seat has its own number.
 * 
 * @author Willem Hoogsteen
 * @version 1.1 2020.02.02
 */
public class Seat {
    
    int seatNumber;
    boolean isReserved;
    
    /**
     * Constructor for seats reserved/free seatnumber
     * @param isReserved for set the seat reserve.
     * @param seatNumber for the seatnumber of each seat
     */
    public Seat(boolean isReserved, int seatNumber)
    {
        this.isReserved = isReserved;
        this.seatNumber = seatNumber;
    }
    
    /**
     * Sets the seatnumber
     * @param seatNumber The seatnumber of a seat
     */
    public void setSeatNumber(int seatNumber)
    {
        this.seatNumber = seatNumber;
    }
    
    /**
     * Return a seatnumber of a seat
     * @return seatNumber The seatnumber of a seat.
     */
    public int getSeatNumber()
    {
        return this.seatNumber;
    }
    
    /**
     * Return a reservationstatus of a seat
     * @return isReserved The reservationstatus of a seat.
     */
    public boolean getReservationStatus()
    {
        return isReserved;
    }
    
    /**
     * Sets the seatreservation on true.
     * 
     */
    public void reserve()
    {
        isReserved = true;
    }
    
    /**
     * Sets the seatreservation on false
     * 
     */
    public void unreserve()
    {
        isReserved = false;
    }   

}