import java.util.*;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.time.LocalDate;
import java.text.DecimalFormat;
import java.time.Month;
 /**
 * A class that let you choose from an optionmenu what action
 * you want to take in a CinemaReservationSystem.
 * 
 * @author (Willem Hoogsteen)
 * @version (1.1 2020.02.02)
 */  
public class CinemaReservationSystem
    {   
      //collections
      ArrayList<Show >shows = new ArrayList<Show>();
      ArrayList<SeatPlan>seatPlans = new ArrayList();
      ArrayList<Theatre> theatres = new ArrayList<Theatre>();
      ArrayList<SeatReservation> seatReservations = new ArrayList<SeatReservation>();
      ArrayList<Customer> customers = new ArrayList<Customer>();
      
      
      private Theatre theatre;
      private SeatPlan seatPlan;
      private Show show;
      
      private int seatPlanNumber;// a number and a description
      private int theatreNumber;// a number and a description
      private int showNumber;
      private int seatNumber;
      private int rowClassNumber;
      private int rowNumber;
      private int customerId;
      private int rowCountNumber;
      private int rangeOfRow;
      private int repeat;
      //private int anotherYear;
      private String seatPlanName;
      private String theatreName;      
      private String showDate;// without pattern 30122020      
      private String showName;

      private int maxRowClasses = 3;
      private int customerIdMax   = 9999;
      private int maxRangeOfRows = 100;
      private int maxSeatNumber = 250;
      private int maxRowCountNumbers = 800;
      private int repeatMaxNumber = 2;
      private int numDays;
      
      public String decimalPattern = "###,###,###.##";      
      
      // option variable if option equals "6" it ends the program
      private String option;                    
      private OptionMenu menu;
      
      // dates and so on              
      private LocalDate date;
      private int month;
      private LocalDate year;
      private LocalDate anotherSummerDay;
      private LocalDate toDay;
      
      private String showDayString;
      private String showMonthString;
      private String showYearString;
      private int showDay;
      private int showMonth;
      private int showYear;
      private String currentDayString;
      private String currentMonthString;
      private String currentYearString;
      private int currentDay;
      private int currentMonth;
      private int currentYear;
      
      private boolean isAfter;
      private boolean isBefore;
      private boolean isLeapYear;
      
      // valid numbers names
      private boolean validSeatPlanName;
      private boolean validSeatPlanNumber;
      private boolean validTheatreName;
      private boolean validTheatreNumber;
      private boolean validShowNumber;
      private boolean validRowNumber;
      private boolean validSeatNumber;
      private boolean validCustomerIdNumber;
      private boolean validRowClassNumber;
      private boolean validRowCountNumber;
      private boolean validRangeOfRowNumber;
      private boolean validRepeatNumber;
      //private boolean validShowDate;
      private boolean validShowName;
      private boolean validShowDay;
      private boolean validShowMonth;
      private boolean validShowYear;
      
      //indicator new theatre, theatrename, show etc.
      private boolean newSeatPlan;
      private boolean newSeatPlanName;
      private boolean newTheatre;
      private boolean newTheatreName;
      private boolean newShow;
      private boolean newRowNumber;
      private boolean newRowClass;
      private boolean newNumberOfSeats;
      private boolean newCustomerId;                    
      private boolean newRowCountNumber;
      private boolean newRangeOfRowNumber;
      private boolean newShowDate;
      
      //private int costumerId=0;// strange spelling??
      /**
       * Creates an inputreader for input.
       */
      public CinemaReservationSystem()
      {                    
            menu = new OptionMenu();
      } 
     
      /**
       * Cinema SeatReservation system option menu.
       * 
       */
      public void startCinemaSystemOptionMenu()throws Exception
      {               
         //Test Objects
         Theatre testTheatre = new Theatre(0, "Cinema 1");
         theatres.add(testTheatre);
         Theatre testTheatre1 = new Theatre(1, "Cinema 2");
         theatres.add(testTheatre1);
         Theatre testTheatre2 = new Theatre(2, "Cinema 3");
         theatres.add(testTheatre2);
         
         SeatPlan testSeatPlan = new SeatPlan(0,"seats for theatre 1");         
         seatPlans.add(testSeatPlan);
         SeatPlan testSeatPlan1 = new SeatPlan(1,"seats for theatre 2");        
         seatPlans.add(testSeatPlan1);
         SeatPlan testSeatPlan2 = new SeatPlan(2,"seats for theatre 3");         
         seatPlans.add(testSeatPlan2);
         
         Show testShow = new Show("Honeymoon - Movie", "30012020",testSeatPlan, testTheatre,0,0);
         testShow.createRows(1, 18, 26,1);
         shows.add(testShow);
         Show testShow1 = new Show("Starwars - Movie", "30012020",testSeatPlan1, testTheatre1,1,1);
         testShow1.createRows(1, 20, 6,1);
         testShow1.createRows(2, 22, 10,7);
         testShow1.createRows(3, 26, 16,17);
         shows.add(testShow1);
         Show testShow2 = new Show("SpongeBob Schwammkopf - Movie", "31012020",testSeatPlan1, testTheatre1,2,1);
         testShow2.createRows(1, 15, 6,1);
         testShow2.createRows(2, 19, 10,7);
         testShow2.createRows(3, 21, 16,17);
         shows.add(testShow2);         
         Show testShow3 = new Show("HoneyPot - Movie", "31012020",testSeatPlan1, testTheatre1,3,1);         
         testShow3.createRows(1, 15, 6,1);
         testShow3.createRows(2, 19, 10,7);
         testShow3.createRows(3, 21, 16,17);             
         shows.add(testShow3);
         Show testShow4 = new Show("Return to Cassandria - Movie","02022020",testSeatPlan2, testTheatre2,4,2);
         testShow4.createRows(1, 10, 5,1);
         testShow4.createRows(2, 14, 8,6);
         testShow4.createRows(3, 20, 12,14);
         shows.add(testShow4);         
         
                            
         do
          {  
              menu.printOptionMenu();                     
              //input and check if it is a valid option                     
             while(!validOption(option)){}
                                             
               if(option.equals("1"))
                {  
                    System.out.println("ADD THEATRE ");
                    System.out.println("-------------------------\n");
                    
                    System.out.print("Existing numbers for the theatres are : \n"); 
                    for (int i=0; i < theatres.size(); i++) 
                    {                                                           
                     System.out.println(i+1 + " " + theatres.get(i).getDescription());
                    }
                    System.out.print("Enter a name for the theatre : \n");
                    while(!validTheatreName(theatreName, newTheatreName)){} 
                    newTheatreName = true;                                                                       
                    System.out.print("selected a number for the theatre : "+(theatres.size()+1 )+" \n");
                    theatreNumber = (theatres.size()+1);
                    this.theatreNumber = theatreNumber;
                    newTheatre = true;                    
                    while(!validTheatreNumber(theatreNumber, newTheatre)){}                                                                                       
                    theatre = new Theatre(theatreNumber-1, theatreName);               
                    theatres.add(theatre);
                    System.out.println("theatre # "+theatreName +" # is added:");  
                           
                                                      
                }
                 
                if(option.equals("2"))
                {  
                  System.out.println("ADD SEATPLAN ");
                    System.out.println("-------------------------5\n");
                    System.out.println("Existing seatPlans are : \n");
                    for (int i=0; i < seatPlans.size(); i++) 
                    {                                                           
                       System.out.println(i+1 + " "
                       + seatPlans.get(i).getSeatPlanDescription());
                    }
                    newSeatPlanName = true;  
                    System.out.print("Enter a name for the seatPlan : \n");                                      
                    while(!validSeatPlanName(seatPlanName, newSeatPlanName)){} 
                    seatPlanNumber = seatPlans.size()+1;
                    System.out.print("selected a number for the seatPlan : "+seatPlanNumber+" \n" );                                                        
                    newSeatPlan = true;                    
                    while(!validSeatPlanNumber(seatPlanNumber, newSeatPlan)){}                       
                    this.seatPlanNumber = seatPlanNumber;
                    seatPlan = new SeatPlan(seatPlanNumber-1, seatPlanName);                    
                    seatPlans.add(seatPlan);
                    System.out.println("seatPlan # "+seatPlanName +" #  is added:");  
                }
                
                if(option.equals("3"))
                 {                           
                     System.out.println("ADD SHOW  ");
                     System.out.println("-------------------------\n");                     
                     newShowDate = true;
                     // day may not before today and not after 180 days from now                     
                     //while(!validShowDate(showDate, newShowDate)){}
                     do{ System.out.println("Enter the year of the Show [YYYY]: ");
                         validShowYear(showYear, newShowDate);
                         
                         System.out.println("Enter the month of the Show [MM]: ");
                         validShowMonth(showMonth, newShowDate);
                         
                         System.out.println("Enter the day of the Show [DD]: ");
                         validShowDay(showDay, newShowDate);
                         if(showDay < 10){showDayString ="0" +showDay;}
                         else
                         {showDayString =""+showDay;}
                         
                         
                         if(showMonth < 10){showMonthString ="0" +showMonth;}
                         else
                         {showMonthString =""+showMonth;}
                         showYearString =""+showYear;
                         
                         showDate = ""+showDayString+showMonthString+showYearString;
                         
                        }
                     while(isBefore(isBefore) || isAfter(isAfter));
                                          
                     System.out.print("Enter name of Show: \n");                            
                     newShow = true;
                     while(!validShowName(showName, newShow)){}
                            System.out.print("Existing numbers for theatres are : \n");              
                            
                            for (int i=0; i < theatres.size(); i++) 
                            {                                                           
                            System.out.println(i+1 + " " + theatres.get(i).getDescription());
                            }
                            System.out.println("Select a theatre by typing an existing number : \n"); 
                            newTheatre = false;
                            while(!validTheatreNumber(theatreNumber, newTheatre)){}
                            this.theatreNumber = theatreNumber; 
                            System.out.print("Existing numbers for seatPlans are : \n"); 
                            for (int i=0; i < seatPlans.size(); i++) 
                            {                                                           
                            System.out.println(i+1 + " "
                            +seatPlans.get(i).getSeatPlanDescription());
                            } 
                            System.out.println("Selecting seatPlan for : "+theatreNumber+"  "+ theatres.get(theatreNumber-1).getDescription());   
                            seatPlanNumber = theatreNumber-1;
                            theatreNumber = theatreNumber-1;
                            newSeatPlan = false;
                            while(!validSeatPlanNumber(seatPlanNumber, newSeatPlan)){}                            
                            
                            
                            
                            
                            
                          searchExistingTheatreShowTwin();
                }
     
                if(option.equals("4"))
                 {
                     System.out.println("DISPLAY SHOWS Selected");
                      System.out.println("-------------------------\n");
                      
                      //SimpleDateFormat myFormat = new SimpleDateFormat("DD-MM-YYYY");
                     
                      
                        for (int i = 0; i < shows.size(); i++)
                            {   
                                showNumber = i+1;                                
                                //System.out.println("Show Number: " + shows.get(i).getShowNumber());
                                System.out.println("Show Number: " + showNumber);
                                System.out.println("Show Name: " + shows.get(i).getShowName());
                                showDate = shows.get(i).getShowDate();
                                // setting of the right showdate
                                                             
                                String europeanDatePattern = "dd-MM-yyyy";
                                DateTimeFormatter europeanDateFormatter = DateTimeFormatter.ofPattern(europeanDatePattern); 
                                //DateValidator dateValidator = new DateValidatorImpl(dateFormatter);
                                //dateValidator.isValid(showName); 
                                //CallInterfaceMethod.main(showDate)                                
                                getShowDayMonthYear();
                                
                                
                                
                                System.out.println("Show Date: " + europeanDateFormatter.format(LocalDate.of(showYear, showMonth,showDay )));
                                System.out.println("Show Theatre: " + shows.get(i).getTheatre().getDescription());                                
                                seatPlanNumber = shows.get(i).getSeatPlanNumber();
                                seatPlanNumber +=1;
                                System.out.println("Show SeatplanNumber: " + seatPlanNumber);
                                
                                //System.out.println("Seat Status:" + shows.get(i).getFreeSeatsCount());
                                System.out.println("\n");
                            }
                            System.out.println("End of Show List.\n");
                        }
                        
                        
                if(option.equals("5"))
                {   
                    System.out.println("MAKE SeatReservation Selected");
                    System.out.println("-------------------------\n");
                    System.out.println("Is an customerid available : Yes = 1/No = 2 ");
                    while(!validRepeatNumber(repeat)){}
                    if (repeat == 1)
                    {
                        System.out.println("Select a customerId by typing the customernumber: ");
                        newCustomerId = false;
                        while(!validCustomerIdNumber(customerId, newCustomerId)){}
                            
                    }else
                            
                    if (repeat == 2)
                    {  System.out.println("System produces a customerId  ");
                       newCustomerId = true;  
                       do
                       {                        
                        Random rnd = new Random();
                        customerId = rnd.nextInt(customerIdMax);                        
                       }
                       while(!validCustomerIdNumber(customerId, newCustomerId));
                    } 
                        Customer customer = new Customer(customerId);
                        customers.add(customer);
                        for (int i = 0; i< shows.size(); i++)
                            {                       
                            showNumber = i+1;
                      
                            System.out.println("Show Number: " + showNumber);
                            System.out.println("Show Name:   " + shows.get(i).getShowName());
                            showDate = shows.get(i).getShowDate();
                            String europeanDatePattern = "dd-MM-yyyy";
                            DateTimeFormatter europeanDateFormatter = DateTimeFormatter.ofPattern(europeanDatePattern); 
                            getShowDayMonthYear();
                            //System.out.println("Show Date: " + LocalDate.from(DateTimeFormatter.ISO_LOCAL_DATE.parse(showDate)));
                            System.out.println("Show Date: " + europeanDateFormatter.format(LocalDate.of(showYear, showMonth,showDay )));
                            System.out.println("Show Theatre: " + shows.get(i).getTheatre().getDescription());                                                       
                            seatPlanNumber = shows.get(i).getSeatPlanNumber();
                            seatPlanNumber +=1;
                            System.out.println("Show SeatplanNumber: " + seatPlanNumber);
                            System.out.print("\n");
                            }                            
                            System.out.println("-------------------------");                 
                            System.out.print("Enter the show number: ");                            
                            
                            newShow = false;
                            while(!validShowNumber(showNumber, newShow)){}                               
                                                                                                            
                            repeat = 0;
                            System.out.println();
                                    
                      do { 
                         shows.get(showNumber-1).printSeatPlan();
                         show =shows.get(showNumber-1);//
                         theatre = show.getTheatre();//
                         seatPlan = shows.get(showNumber-1).getSeatPlan();                         
                         System.out.print("Enter the row: ");
                         newRowNumber = false;
                         while(!validRowNumber(rowNumber, newRowNumber)){}                                                                                                                                    
                         System.out.print("Enter the seat: ");                                                                                               
                         newNumberOfSeats = false;
                         while(!validSeatNumber(seatNumber, newNumberOfSeats)){}                                                                                                     
                         System.out.println();
                         SeatReservation seatReservation = new SeatReservation(customer, seatPlan,shows.get(showNumber-1));
                         if (seatReservation.reserveSeat(rowNumber-1, seatNumber-1)) {                         
                             seatReservations.add(seatReservation);
                             System.out.println("The seat is now reserved for you.");
                                }
                             else {
                             System.out.println("Sorry the seat is already reserved.");
                                    
                                }
                         System.out.println();
                         System.out.print("Enter 1 to reserve another seat or 2 to check out: ");                                                                
                         while(!validRepeatNumber(repeat)){}
                                
                        } while (repeat == 1);
                          System.out.println();
                          System.out.println("Your Bill");
                          System.out.println("-------------------------");
                          double totalCost = 0;
                          for (SeatReservation seatReservation : seatReservations)
                            {
                           if (seatReservation.getCustomerX().getId() == customer.getId())
                                {
                               totalCost += seatReservation.getCost();
                                }
                            }
                          System.out.println("Customer ID: " + customer.getId());
                          DecimalFormat myDecimalFormat = new DecimalFormat(decimalPattern);
                          String output = myDecimalFormat.format(totalCost);
                          System.out.println("Total costs: " + output + " Euro");
                          System.out.println();
                }
                        
                if(option.equals("6"))
                 {
                      customerId = 0;
                      System.out.println("CANCEL SeatReservation Selected");
                      System.out.println("-------------------------\n");
                      System.out.print("Enter the customer id: ");
                      newCustomerId = false;                            
                            while(!validCustomerIdNumber(customerId, newCustomerId)){}
                            
                            for (Customer customer : customers) {
                                if (customer.getId() == customerId)
                                {
                                    for(SeatReservation seatReservation : seatReservations)
                                    {
                                        if (seatReservation.getCustomerX().getId() == customer.getId())
                                        {
                                            if (seatReservation.unreserveSeat())
                                            {
                                                
                                            }
                                        }
                                    }
                                    System.out.println("Your reservation has been canceled!");
                                }else{System.out.println("customer has not been found");}
                            }
                            System.out.println();
                        }

              if(option.equals("7"))
               {
                    System.exit(0);
               }

                  }while(true);
                  
            }

      /**
       * Determine whether the entered option is valid.
       * Print an error message if it is not.
       * @param option The String to be checked.
       * @return true if the option is valid, false otherwise.
       */
       private boolean validOption(String option)
       {
                          // The return value.
                          // Set according to whether the index is valid or not.
                          boolean validOption=false;

                try
                {           option = new InputStringReader(option).getStringInput();
                            this.option = option;
                            int j = Integer.valueOf(option);
                  // the String to int conversion happens here                  
                  int i = j ;//Integer.parseInt(option.trim());// this was the old parsing
                 if(i <= 0) {
                              System.out.println("Option cannot be negative or zero: " + option);
                              validOption = false;
                            }else if(i > 7) {
                                System.out.println("Option is too large: " + option);
                                validOption = false;
                                            }else {
                                                validOption = true;
                                            }
                } 
                
                catch (NumberFormatException nfe)
                {   
                  System.out.println("NumberFormatException: in validOption method " + nfe.getMessage());
                  System.out.println("  enter new option again: ");
                  return validOption = false;
                }
                return validOption;     
            }
            
            /**
       * Determine whether the entered seatplanname is valid.
       * Print an error message if it is not.
       * @param seatPlanName The String to be checked.
       * @return true if the option is valid, false otherwise.
       */
       private boolean validSeatPlanName(String seatPlanName, boolean newSeatPlanName)
       {
                // The return value.
                // Set according to whether the index is valid or not.
                validSeatPlanName=false;          
                seatPlanName = new InputStringReader(seatPlanName).getStringInput();                                  
                this.seatPlanName = seatPlanName;
                if(newSeatPlanName){            
                if(seatPlanName.isEmpty()||seatPlanName.equals(" "))
                 {                     
                System.out.println("so this seatplanname : "+ seatPlanName +"\n" +" is Empty, enter a new seatplanname again \n");
                return validSeatPlanName = false;
                 }
                else{                  
                  if(seatPlanName.length() >25) {                              
                                System.out.println("seatplanname is too large: " + seatPlanName);
                                validSeatPlanName = false;
                                               }
                             else {
                                 validSeatPlanName = true;
                                  }                                            
                     }
                              }
                if(!newSeatPlanName){            
                if(seatPlanName.isEmpty()||seatPlanName.equals(" "))
                 {                     
                System.out.println("so this seatplanname : "+ seatPlanName +"\n" +" is Empty, enter a new theatrename again \n");
                return validSeatPlanName = false;
                 }
                else{                  
                  if(seatPlanName.length() >25) {                              
                                System.out.println("seatplanname is too large: " + seatPlanName);
                                validSeatPlanName = false;
                                               }
                             else {
                                 validSeatPlanName = true;
                                  }                                            
                     }
                                  
              }
                                
                return validSeatPlanName;     
            }
           
            /**
             * Determine whether the entered seatPlanNumber is valid.
             * Print an error message if it is not.
             * @param seatPlanNumber The Int to be checked.
             * @return true if the option is valid, false otherwise.
             */
            private boolean validSeatPlanNumber(int seatPlanNumber,boolean newSeatPlan)
            {
                          // The return value.
                          // Set according to whether the index is valid or not.
                          validSeatPlanNumber=false;
                          this.newSeatPlan =newSeatPlan;   
                  
                if(newSeatPlan)
                {
                      //seatPlanNumber = new InputIntReader(seatPlanNumber).getIntInput();
                      this.seatPlanNumber = seatPlanNumber; 
                      int i = seatPlanNumber;
                 if(i <= 0)
                 {
                      System.out.println("Choice cannot be negative or zero: " + seatPlanNumber);
                      validSeatPlanNumber = false;
                 }
                   else if(i <= seatPlans.size())
                   {
                      System.out.println("this is an existing theatre : " + seatPlanNumber);
                      validSeatPlanNumber = false;
                   }
                   else
                      {
                       validSeatPlanNumber = true;
                                            
                      }  
                }
                
                if(!newSeatPlan)
                {int i = seatPlanNumber;
                 if(i <= 0) 
                 {
                      System.out.println("Choice cannot be negative or zero: " + seatPlanNumber);
                      validSeatPlanNumber = false;
                 }
                 else if(i > seatPlans.size())
                   {
                      System.out.println("Choice is too large: " + seatPlanNumber);
                      validSeatPlanNumber = false;
                    }
                 else 
                    {
                      validSeatPlanNumber = true;
                                            
                    }
                }   
               
                return validSeatPlanNumber;     
            }
            
      /**
       * Determine whether the entered theatrename is valid.
       * Print an error message if it is not.
       * @param theatreName The String to be checked.
       * @return true if the option is valid, false otherwise.
       */
       private boolean validTheatreName(String theatreName, boolean newTheatreName)
       {
                // The return value.
                // Set according to whether the index is valid or not.
                validTheatreName=false;          
                theatreName = new InputStringReader(theatreName).getStringInput();                                  
                this.theatreName = theatreName;
                if(newTheatre){            
                if(theatreName.isEmpty()||theatreName.equals(" "))
                 {                     
                System.out.println("so this theatrename : "+ theatreName +"\n" +" is Empty, enter a new theatrename again \n");
                return validTheatreName = false;
                 }
                else{                  
                  if(theatreName.length() >25) {                              
                                System.out.println("theatrename is too large: " + theatreName);
                                validTheatreName = false;
                                               }
                             else {
                                 validTheatreName = true;
                                  }                                            
                     }
                              }
                if(!newTheatre){            
                if(theatreName.isEmpty()||theatreName.equals(" "))
                 {                     
                System.out.println("so this theatrename : "+ theatreName +"\n" +" is Empty, enter a new theatrename again \n");
                return validTheatreName = false;
                 }
                else{                  
                  if(theatreName.length() >25) {                              
                                System.out.println("theatrename is too large: " + theatreName);
                                validTheatreName = false;
                                               }
                             else {
                                 validTheatreName = true;
                                  }                                            
                     }
                                  
              }
                                
                return validTheatreName;     
            }
           
            /**
             * Determine whether the entered theatreNumber is valid.
             * Print an error message if it is not.
             * @param theatreNumber The Int to be checked.
             * @return true if the option is valid, false otherwise.
             */
            private boolean validTheatreNumber(int theatreNumber,boolean newTheatre)
            {
                          // The return value.
                          // Set according to whether the index is valid or not.
                          validTheatreNumber=false;
                              
                        
                          this.newTheatre =newTheatre;
                          
                  
                if(newTheatre)
                {   this.theatreNumber = theatreNumber;                                          
                    int i = theatreNumber;
                          
                    if(i <= 0)
                    {
                              System.out.println("Choice cannot be negative or zero: " + theatreNumber);
                              validTheatreNumber = false;
                            }else if(i <= theatres.size()) {
                                System.out.println("this is an existing theatre : " + theatreNumber);
                                validTheatreNumber = false;
                                            }else {
                                                validTheatreNumber = true;
                                            
                                                  }  
                }else
                 if(!newTheatre){theatreNumber = new InputIntReader(theatreNumber).getIntInput();
                            this.theatreNumber = theatreNumber;
                            int i = theatreNumber;
                 if(i <= 0) {
                              System.out.println("Choice cannot be negative or zero: " + theatreNumber);
                              validTheatreNumber = false;
                            }else if(i > theatres.size()) {
                                System.out.println("Choice is too large: " + theatreNumber);
                                validTheatreNumber = false;
                                            }else {
                                                validTheatreNumber = true;
                                            
                }}   
               
                return validTheatreNumber;     
            }
            
            /**
              * Determine whether the entered showNumber is valid.
              * Print an error message if it is not.
              * @param showNumber The Int to be checked.
              * @return true if the option is valid, false otherwise.
              */
            private boolean validShowNumber(int showNumber, boolean newShow)
            {
                          // The return value.
                          // Set according to whether the index is valid or not.
                          validShowNumber=false;
                          
             
                      //this.newShow=newShow;
                          showNumber = new InputIntReader(showNumber).getIntInput();
                          this.showNumber = showNumber;      
                int i = showNumber;//only with Integer
                if(newShow){ 
                if(i <= 0) {    
                     System.out.println("Choice cannot be negative or zero: " + showNumber);
                              validShowNumber = false;                            
                            }else if
                            (i <= shows.size()) {
                                System.out.println("This is an existing shownumber: " + showNumber);
                                validShowNumber = false;
                                            }else {
                                                validShowNumber = true;
                                                  }
                           }else
                if(!newShow){
                  if(i <= 0) {
                              System.out.println("Choice cannot be negative or zero: " + showNumber);
                              validShowNumber = false;
                            }else if(i > shows.size()) {
                                System.out.println("Choice is too large: " + showNumber);
                                validShowNumber = false;
                                            }else {
                                                validShowNumber = true;
                                            }
                             }
                            
                return validShowNumber;     
            }            
            
            /**
              * Determine whether the entered rowNumber is valid.
              * Print an error message if it is not.
              * @param selectedRow The Int to be checked.
              * @return true if the option is valid, false otherwise.
              */
            private boolean validRowNumber(int rowNumber,boolean newRowNumber)
            {
                          // The return value.
                          // Set according to whether the index is valid or not.
                          validRowNumber=false;
                          
                   rowNumber = new InputIntReader(rowNumber).getIntInput();        
                    this.rowNumber = rowNumber;       
                  int i = rowNumber;
                 if(newRowNumber){ 
                 if(i <= 0) {
                              System.out.println("Choice cannot be negative or zero: " + rowNumber);
                              validRowNumber = false;
                            }else if(i > maxSeatNumber) {
                                System.out.println("Choice is too large: " + rowNumber);
                                validRowNumber = false;
                                            }else {
                                                validRowNumber = true;
                                            }
                                 } 
                 if(!newRowNumber){
                 int j = show.getRows().size();
                 if(i <= 0) {
                              System.out.println("Choice cannot be negative or zero: " + rowNumber);
                              validRowNumber = false;
                             
                            }else if(i > j){
                                System.out.println("Choice is too large: " + rowNumber);
                                validRowNumber = false;
                                            }else {
                                                validRowNumber = true;
                                            }
                                 }                  
                
                return validRowNumber;     
            }
            
            /**
              * Determine whether the entered seatNumber is valid.
              * Print an error message if it is not.
              * @param selectedSeat The Int to be checked.
              * @return true if the option is valid, false otherwise.
              */
            private boolean validSeatNumber(int seatNumber, boolean newNumberOfSeats)
            {
                          // The return value.
                          // Set according to whether the index is valid or not.
                          validSeatNumber=false;
                          
                        seatNumber = new InputIntReader(seatNumber).getIntInput();
                          this.seatNumber =seatNumber;// if true ment to be number of seats in row
                                                        // if false ment to be The seatnumber
                          
                          //this.newNumberOfSeats =newNumberOfSeats;
                                                
                 int i = seatNumber;
                 if(newNumberOfSeats){
                 if(i <= 0) {
                              System.out.println("Choice cannot be negative or zero: " + seatNumber);
                              validSeatNumber = false;
                             }
                 else if(i> maxSeatNumber) {
                                System.out.println("Choice is too large: " + seatNumber);
                                validSeatNumber = false;
                                  }
                 else {
                               validSeatNumber = true;
                      }
                                     }                                              
                 if(!newNumberOfSeats){
                 int j =show.getRows().get(rowNumber-1).getSeats().size();    
                 if(i <= 0) {
                              System.out.println("Choice cannot be negative or zero: " + seatNumber);
                              validSeatNumber = false;
                             }else if(i >j) {
                                System.out.println("Choice is too large: " + seatNumber);
                                validSeatNumber = false;
                                                            }else {
                                                validSeatNumber = true;
                                                                  }  
                                              }                                                 
           
                return validSeatNumber;     
            }
            
            /**
              * Determine whether the entered customerIdNumber is valid.
              * Print an error message if it is not.
              * @param customerId The Int to be checked.
              * @return true if the customerId is valid, false otherwise.
              */
            private boolean validCustomerIdNumber(int customerId, boolean newCustomerId)
            {
                          // The return value.
                          // Set according to whether the index is valid or not.
                          validCustomerIdNumber=false;                          
                          //customerId = new InputIntReader().getIntInput();
                          this.customerId = customerId; 
                          
                          int i = customerId;
                  if(newCustomerId)
                  {     
                       System.out.println("selected customer number: "+customerId);  
                         if(i <= 0) 
                         {
                          System.out.println("Choice cannot be negative or zero: " + customerId);
                              validCustomerIdNumber = false;}
                         else if(i > customerIdMax)
                          {
                                System.out.println("Choice is too large: " + customerId);
                                validCustomerIdNumber = false;
                          }
                          
                          // customerId found / not found
                         else if(customers.isEmpty())
                         {   // ArrayList customers is empty
                             // so there is no customer by that id number so it is valid
                                System.out.println("is valid customer (system customers was empty) ");
                                validCustomerIdNumber = true;
                         }
                         else if(!customers.isEmpty())                         
                         {     // chech if the system did not produce a double customernumber
                               // the ArrayList customers is  not empty
                               // a customer possibly could be found then
                             for (Customer customer : customers)
                             {
                                if (customer.getId() == customerId)
                                {
                                    for(SeatReservation seatReservation : seatReservations)
                                    {

                                    if (seatReservation.getCustomerX().getId() == customer.getId())
                                        {  // it exists already so it is not valid                                       
                                         System.out.println("this customernumber already exists");
                                         validCustomerIdNumber = false;
                                        }
                                    }
                                }                                                    
                            }                        
                            // when we get here
                            // there is no customer found by the systems created id number so it is valid
                            System.out.println("is valid customer number,no equal customer number found");
                            validCustomerIdNumber = true;
                         }                      
                 
                 }
                 
                 if(!newCustomerId)
                 { 
                          customerId = new InputIntReader(customerId).getIntInput();
                          this.customerId = customerId;
                           
                        System.out.println("selected customer number: "+customerId);  
                         if(i <= 0) 
                         {
                          System.out.println("Choice cannot be negative or zero: " + customerId);
                              validCustomerIdNumber = false;}
                         else if(i > customerIdMax)
                          {
                                System.out.println("Choice is too large: " + customerId);
                                validCustomerIdNumber = false;
                          }
                          
                          // customerId found / not found
                         else if(customers.isEmpty())
                         {   // ArrayList customers is empty ther are no valid customers
                             // so there is no customer by that id number so it is not valid
                                System.out.println("file is empty so this is not a valid customer ");
                                validCustomerIdNumber = false;
                         }
                         else if(!customers.isEmpty())
                         {   
                          // the ArrayList customers is  not empty
                          // a customer possibly could be found then
                          boolean found1 = false;
                          boolean found2= false;
                         do
                         {
                           for (Customer customer : customers)
                           {  
                               if (customer.getId() == customerId)
                              { 
                                found1 = true;
                                do
                                {
                                   for(SeatReservation seatReservation : seatReservations)
                                   {                                
                                         if(seatReservation.getCustomerX().getId() == customer.getId())
                                         { 
                                             //do nothing customer is found
                                             System.out.println("valid customer : "+customerId);
                                             found2 = true;
                                             validCustomerIdNumber = true;
                                         }
                                   
                                   }
                                }while(!found2);
                              }
                           }
                            // when we get here  the client must have given a wrong customernumber
                            // there is no customer found by the entered customer number so it is not valid
                            System.out.println("sorry but you gave us a wrong number, this one is not in our system");
                            validCustomerIdNumber = false;
                         }while(!found1);
                        
                          }                       
                }
                return validCustomerIdNumber;     
            }

            /**
              * Determine whether the entered rowClassNumber is valid.
              * Print an error message if it is not.
              * @param rowClassNumber The Int to be checked.
              * @return true if the option is valid, false otherwise.
              */
            private boolean validRowClassNumber(int rowClassNumber,boolean newRowClass)
            {
                          // The return value.
                          // Set according to whether the index is valid or not.
                          validRowClassNumber=false; 
                          
                      
                                                                
                       rowClassNumber = new InputIntReader(rowClassNumber).getIntInput();
                       this.rowClassNumber = rowClassNumber;   
                 int i = rowClassNumber;
                 if(newRowClass){
                 if(i <= 0)
                {
                              System.out.println("Choice cannot be negative or zero: " + rowClassNumber);
                              validRowClassNumber = false;
                            }else if(i >= maxRowClasses) {
                                System.out.println("Choice is too large: " + rowClassNumber);
                                validRowClassNumber = false;
                                            }else {
                                                validRowClassNumber = true;
                                            
                                                  }  
                }else
                 if(!newRowClass){
                 if(i <= 0) {
                              System.out.println("Choice cannot be negative or zero: " + rowClassNumber);
                              validRowClassNumber = false;
                            }else if(i >= maxRowClasses) {
                                System.out.println("Choice is too large: " + rowClassNumber);
                                validRowClassNumber = false;
                                            }else {
                                                validRowClassNumber = true;
                                            
                }}   
               
                
                return validRowClassNumber;     
            }
            
            /**
              * Determine whether the entered rowCountNumber is valid.
              * Print an error message if it is not.
              * @param rowCountNumber The Int to be checked.
              * @return true if the rowCountNumber is valid, false otherwise.
              */
            private boolean validRowCountNumber(int rowCountNumber, boolean newRowCountNumber)
            {
                          // The return value.
                          // Set according to whether the index is valid or not.
                          validRowCountNumber=false;
                         
                          
                          rowCountNumber = new InputIntReader(rowCountNumber).getIntInput(); 
                          this.rowCountNumber = rowCountNumber;                                    
                                                      
                  int i = rowCountNumber;
                 if(newRowCountNumber){ 
                 if(i <= 0) {
                              System.out.println("Choice cannot be negative or zero: " + rowCountNumber);
                              validRowCountNumber = false;
                            }else if(i > maxRowCountNumbers) {
                                System.out.println("Choice is too large: " + rowCountNumber);
                                validRowCountNumber = false;
                                            }else {
                                                validRowCountNumber = true;
                                            }
                                        }
                 if(!newRowCountNumber){
                 int j = show.getRows().size();
                 if(i <= 0) {
                              System.out.println("Choice cannot be negative or zero: " + rowCountNumber);
                              validRowCountNumber = false;
                            }else if(i > j) {
                                System.out.println("Choice is too large: " + rowCountNumber);
                                validRowCountNumber = false;
                                            }else {
                                                validRowCountNumber = true;
                                            }
                                        }                       
                
                return validRowCountNumber;     
            }
           
            /**
              * Determine whether the entered rowNumber is valid.
              * Print an error message if it is not.
              * @param selectedRow The Int to be checked.
              * @return true if the option is valid, false otherwise.
              */
            private boolean validRangeOfRowNumber(int rangeOfRow, boolean newRangeOfRowNumber)
            {
                          // The return value.
                          // Set according to whether the index is valid or not.
                          validRangeOfRowNumber=false;
                          
                          rangeOfRow = new InputIntReader(rangeOfRow).getIntInput();
                          this.rangeOfRow = rangeOfRow;                                             
                                                      
                 int i = rangeOfRow;
                 if(newRangeOfRowNumber){
                 if(i <= 0) {
                              System.out.println("Choice cannot be negative or zero: " + rangeOfRow);
                              validRangeOfRowNumber = false;
                            }else if(i > maxRangeOfRows) {
                                System.out.println("Choice is too large: " + rangeOfRow);
                                validRangeOfRowNumber = false;
                                            }else {
                                                validRangeOfRowNumber = true;
                                            }
                                        }
                 if(!newRangeOfRowNumber){
                 int j = show.getRows().size();    
                 if(i <= 0) {
                              System.out.println("Choice cannot be negative or zero: " + rangeOfRow);
                              validRangeOfRowNumber = false;
                            }else if(i > j) {
                                System.out.println("Choice is too large: " + rangeOfRow);
                                validRangeOfRowNumber = false;
                                            }else {
                                                validRangeOfRowNumber = true;
                                            }
                                        }                       
                
                return validRangeOfRowNumber;     
            }
            /**
              * Determine whether the entered repeatNumber is valid.
              * Print an error message if it is not.
              * @param repeatNumber The Int to be checked.
              * @return true if the repeatNumber is valid, false otherwise.
              */
            private boolean validRepeatNumber(int repeat)
            {
                          // The return value.
                          // Set according to whether the choiceNumber is valid or not.
                          validRepeatNumber=false;
                          
                          repeat = new InputIntReader(repeat).getIntInput();
                          this.repeat = repeat;                 
                  int i = repeat;
                 if(i <= 0) {
                              System.out.println("Choice cannot be negative or zero: " + repeat);
                              validRepeatNumber = false;
                            }else if(i > repeatMaxNumber) {// repeatmax
                                System.out.println("Choice is too large: " + repeat);
                              validRepeatNumber = false;
                                            }else {
                                                validRepeatNumber = true;
                                            }
                
                return validRepeatNumber;     
            }
            
            
               
             /**
              * Determine whether the entered showYear is valid.
              * Print an error message if it is not.
              * @param showYear The Int to be checked.
              * @return true if the option is valid, false otherwise.
              */
            private boolean validShowYear(int showYear, boolean newShowDate)
            {
                          // The return value.
                          // Set according to whether the index is valid or not.
                          validShowYear=false;
                          getCurrentDayMonthYear();
                        showYear = new InputIntReader(showYear).getIntInput();
                          this.showYear = showYear;                                             
                 int i = showYear;
                
                 if(newShowDate){
                 if(i < currentYear) {
                              System.out.println("Choice cannot be an previous Year: " + showYear);
                              validShowYear = false;
                            }else if(i > currentYear+1) {
                                System.out.println("Choice is too large: " + showYear);
                                validShowYear = false;
                                            }else {
                                                validShowYear = true;
                                            }
                                        }
                 if(!newShowDate){
                 if(i <= 0 || i < currentYear) {
                               System.out.println("Choice cannot be negative or zero or smaller then currentYear: " + showYear);
                              validShowYear = false;
                            }else if(i > currentYear+1) {
                                System.out.println("Choice is too large: " + showYear);
                                validShowYear = false;
                                            }else {
                                                validShowYear = true;
                                            }
                                                               
                }
                return validShowYear;     
            }
           
              /**
              * Determine whether the entered showmonth is valid.
              * Print an error message if it is not.
              * @param showMonth The Int to be checked.
              * @return true if the option is valid, false otherwise.
              */
            private boolean validShowMonth(int showMonth, boolean newShowDate)
            {
                          // The return value.
                          // Set according to whether the index is valid or not.
                          validShowMonth=false;
                         //getCurrentDayMonthYear(); 
                        showMonth = new InputIntReader(showMonth).getIntInput();
                          this.showMonth = showMonth;                                             
                 int i = showMonth;
                
                 if(newShowDate){
                 if(i < currentMonth ) {
                              System.out.println("Choice cannot be an previous Month: " + showMonth);
                              validShowMonth = false;
                            }else if(i > currentMonth+6) {
                                System.out.println("Choice is too large: " + showMonth);
                                validShowMonth = false;
                                            }else {
                                                validShowMonth = true;
                                            }
                                        }
                 if(!newShowDate){
                 if(i <= 0 || i < currentMonth) {
                               System.out.println("Choice cannot be an previous Year: " + showMonth);
                              validShowMonth = false;
                            }else if(i > currentMonth+6) {
                                System.out.println("Choice is too large: " + showMonth);
                                validShowMonth = false;
                                            }else {
                                                validShowMonth = true;
                                            }
                                                               
                }
                return validShowMonth;     
            }
            
               /**
              * Determine whether the entered rowNumber is valid.
              * Print an error message if it is not.
              * @param selectedRow The Int to be checked.
              * @return true if the option is valid, false otherwise.
              */
            private boolean validShowDay(int showDay, boolean newShowDate)
            {
                          // The return value.
                          // Set according to whether the index is valid or not.
                          validShowDay=false;
                          //getCurrentDayMonthYear(); 
                          showDay = new InputIntReader(showDay).getIntInput();
                          this.showDay = showDay;                                             
                          switchday(showMonth, showYear);                                    
                          int i = showDay;
                 if(newShowDate){
                 if(i <= 0) {
                              System.out.println("Choice cannot be negative or zero : " + showDay);
                              validShowDay = false;
                            }else if(showMonth==currentMonth && i < currentDay){
                                System.out.println("Choice cannot be smaller then current Day   : " + showDay);
                                 validShowDay = false;
                            }else if
                            (i > numDays) {
                                System.out.println("Choice is too large: " + showDay);
                                validShowDay = false;
                                            }else {
                                                validShowDay = true;
                                            }
                                        }
                 if(!newShowDate){
                 if(i <= 0) {
                              System.out.println("Choice cannot be negative or zero: " + showDay);
                              validShowDay = false;
                            }else if(showMonth==currentMonth && i < currentDay){
                                System.out.println("Choice cannot be smaller then current Day   : " + showDay);
                                 validShowDay = false;
                            }
                            else if(i > numDays) {
                                System.out.println("Choice is too large: " + showDay);
                                validShowDay = false;
                                            }else {
                                                validShowDay = true;
                                            }
                                        }                       
                
                return validShowDay;     
            }

             /**
              * Determine whether the entered showName is valid.
              * Print an error message if it is not.
              * @param showName The String to be checked.
              * @return true if the option is valid, false otherwise.
              */
            private boolean validShowName(String showName, boolean newShow)
            {
                          // The return value.
                          // Set according to whether the index is valid or not.
                          validShowName=false;
                      
                          showName = new InputStringReader(showName).getStringInput();
                          this.showName = showName;
                          //this.newShow = newShow;                                          
                if(newShow)
                {                                   
                if(showName.isEmpty()||showName.equals(" "))
                {
                    System.out.print("option entered ==== : "+ showName +"\n"); 
                    System.out.println("so this showname is Empty, enter a new showname again");
                return validShowName = false;}
                else{                  
                  if(showName.length() >30) {                              
                                System.out.println("theatrename is too large: " + showName);
                                validShowName = false;
                                            }
                             else {validShowName = true;}                                            
                     }
                }
                 if(!newShow){                                   
                if(showName.isEmpty()||showName.equals(" "))
                {
                    System.out.print("option entered ==== : "+ showName +"\n"); 
                    System.out.println("so this showname is Empty, enter a new showname again");
                return validShowName = false;}
                else{                  
                  if(showName.length() >30) {                              
                                System.out.println("theatrename is too large: " + showName);
                                validShowName = false;
                                            }
                             else {validShowName = true;}                                            
                     }
                           }
               
                return validShowName;     
            }
            
            /**
             * search for an existing combination of theatre and show at same date.
             * 
             * String searchName The String to look for in combination with showDate.
             * if found do nothing and let user start the procedure again.
             * if not found store the new show entered.
             */
            public void searchExistingTheatreShowTwin()
            {
               String searchName =theatres.get(theatreNumber-1).getDescription();
                
                int index = 0;
                //record that will be searching untill match is found.
                boolean searching = true;
                int numberOfShows = shows.size();
               while(searching && index < numberOfShows)
                {
                if(shows.get(index).getShowDate().equals(showDate) && 
                    shows.get(index).getTheatre().getDescription().contains(searchName))                                
                { // a match we can stop searching                                   
                                 searching = false;
                                 
                                 System.out.println("Theatre is occupied by an other show");
                                 System.out.println("so nothing is stored/saved!! ");
                                 System.out.println("try again the option 2 procedure: ");
                                 
                                }else{//move on
                                index++;
                }
            }
                if (searching)
                 {// we didn't find it so we can store this one
                     seatPlan = seatPlans.get(seatPlanNumber);
                     theatre = theatres.get(theatreNumber);
                     showNumber = shows.size()+1;//setting a unique shownumber

                     show = new Show(showName, showDate,seatPlan, theatre, showNumber,seatPlanNumber);                       
                     
                     if(theatreNumber == 0)
                            {int rowClassNumber1 = 1;int rangeOfRow1 = 18; int seatNumber1 = 26;int rowPositionCounter1 = 1; 
                             show.createRows(rowClassNumber1, seatNumber1, rangeOfRow1,rowPositionCounter1);
                             
                            }
                            
                     if(theatreNumber == 1)
                            {int rowClassNumber1 = 1;int rangeOfRow1 = 6; int seatNumber1 = 20;int rowPositionCounter1 = 1;
                             int rowClassNumber2 = 2;int rangeOfRow2 = 10; int seatNumber2 = 22;int rowPositionCounter2 = 7;
                             int rowClassNumber3 = 3;int rangeOfRow3 = 16; int seatNumber3 = 26;int rowPositionCounter3 = 17;
                             show.createRows(rowClassNumber1, seatNumber1, rangeOfRow1,rowPositionCounter1);                            
                             show.createRows(rowClassNumber2, seatNumber2, rangeOfRow2,rowPositionCounter2);                        
                             show.createRows(rowClassNumber3, seatNumber3, rangeOfRow3,rowPositionCounter3);
                            
                            }
                            
                             if(theatreNumber ==2)
                            {int rowClassNumber1 = 1;int rangeOfRow1 = 6; int seatNumber1 = 20;int rowPositionCounter1 = 1;
                             int rowClassNumber2 = 2;int rangeOfRow2 = 10; int seatNumber2 = 22;int rowPositionCounter2 = 7;
                             int rowClassNumber3 = 3;int rangeOfRow3 = 16; int seatNumber3 = 26;int rowPositionCounter3 = 17;
                             show.createRows(rowClassNumber1, seatNumber1, rangeOfRow1,rowPositionCounter1);                            
                             show.createRows(rowClassNumber2, seatNumber2, rangeOfRow2,rowPositionCounter2);                        
                             show.createRows(rowClassNumber3, seatNumber3, rangeOfRow3,rowPositionCounter3);
                            
                            }                                                
                                                     
                              if(theatreNumber ==3)
                            {int rowClassNumber1 = 1;int rangeOfRow1 = 5; int seatNumber1 = 10;int rowPositionCounter1 = 1;
                             int rowClassNumber2 = 2;int rangeOfRow2 = 8; int seatNumber2 = 14;int rowPositionCounter2 = 6;
                             int rowClassNumber3 = 3;int rangeOfRow3 = 12; int seatNumber3 = 20;int rowPositionCounter3 = 14;
                             show.createRows(rowClassNumber1, seatNumber1, rangeOfRow1,rowPositionCounter1);                            
                             show.createRows(rowClassNumber2, seatNumber2, rangeOfRow2,rowPositionCounter2);                        
                             show.createRows(rowClassNumber3, seatNumber3, rangeOfRow3,rowPositionCounter3);
                            
                            }
                            
                              if(theatreNumber ==4)
                            {int rowClassNumber1 = 1;int rangeOfRow1 = 15; int seatNumber1 = 20;int rowPositionCounter1 = 1;
                             int rowClassNumber2 = 2;int rangeOfRow2 = 18; int seatNumber2 = 24;int rowPositionCounter2 = 16;
                             int rowClassNumber3 = 3;int rangeOfRow3 = 25; int seatNumber3 = 26;int rowPositionCounter3 = 34;
                             show.createRows(rowClassNumber1, seatNumber1, rangeOfRow1,rowPositionCounter1);                            
                             show.createRows(rowClassNumber2, seatNumber2, rangeOfRow2,rowPositionCounter2);                        
                             show.createRows(rowClassNumber3, seatNumber3, rangeOfRow3,rowPositionCounter3);
                            
                            }
                            shows.add(show);//saving storing in shows ArrayList
                            System.out.println("valid theatre&show and is saved!! ");                                
                            ///return -1;
                                
                 }
                else
                  {   //return where it was found
                                //return index;
                                
                  }        
              
                }
      /**
       * return boolean notBefore
       * @return notBefore  The boolean to return
       * returns true or false
       */          
      private boolean isBefore(boolean isBefore)
      {
          // not before today boolean
          //currentDate = LocalDate.parse(showYearString+"-"+showMonthString+"-"+showDayString); 
          getShowDayMonthYear();
          getCurrentDayMonthYear();
          if(anotherSummerDay.isBefore(toDay))
          {     isBefore = true; this.isBefore = isBefore;
              return isBefore;}
          else{isBefore = false; this.isBefore = isBefore;
              return isBefore;}
        }
        
      /**
       * return boolean notBefore
       * @return notBefore  The boolean to return
       * returns true or false
       */          
      private boolean isAfter(boolean isAfter)
      {
          // not after today boolean plus 180 days
          //currentDate = LocalDate.parse(showYearString+"-"+showMonthString+"-"+showDayString);

          getShowDayMonthYear();
          getCurrentDayMonthYear();
          if(anotherSummerDay.isAfter(toDay.plusDays(180)))
          { isAfter = true;this.isAfter = isAfter;
              return isAfter;}
          else{isAfter = false; this.isAfter = isAfter;
              return isAfter;}
      }
      
      private boolean isLeapYear()
      {
          if(LocalDate.now().isLeapYear())
          {isLeapYear = true;
              return isLeapYear;
            }else{isLeapYear = false;
                return isLeapYear;}
         
      }
      
      private int switchday(int showMonth, int showYear)
      { 
        numDays = 0;
        
        switch (showMonth){
        case 1: case 3: case 5:
        case 7: case 8: case 10:
        case 12:
            numDays = 31;
                break;
        case 4: case 6:
        case 9: case 11:
            numDays = 30;
                break;
        case 2:
            if(((showYear % 4 == 0) &&
                !(showYear % 100 == 0))
                    ||(showYear % 400 == 0))
                    numDays = 29;
                    else
                        numDays = 28;
                        break;
        default:
        System.out.println("Invalid Month.");
        break;
       }
       return numDays; 
                
      }

      public LocalDate getShowDayMonthYear()
      {    
          //Month month;
          //month= date.getMonth();
          //return month;
          
          Calendar cal=null;
          try{             
          Date date = new SimpleDateFormat("ddMMyyyy").parse(showDate);          
          cal = Calendar.getInstance();
          cal.setTime(date);          
          showDay =cal.get(Calendar.DATE);
          if(showDay < 10){showDayString ="0" +showDay;}
          else
          {showDayString =  ""+showDay;}        
          //System.out.println(showDayString);
          showMonth = cal.get(Calendar.MONTH)+1;
          if(showMonth < 10){showMonthString ="0" +showMonth;}
          else
          {showMonthString =  ""+showMonth;}
          //System.out.println(showMonthString);
          showYear = cal.get(Calendar.YEAR);
          showYearString =  ""+showYear;
          //System.out.println(showYearString);         
          //System.out.println("Month - " + String.format("%02d", (showMonth)));
          //System.out.println("Day - " + String.format("%02d", showDay));
          //System.out.println("Year - " + showYear);          
        }  catch (Exception e) {
            e.printStackTrace();}
           return anotherSummerDay = LocalDate.of(showYear,showMonth,showDay);
        }
      
        public LocalDate getCurrentDayMonthYear()
      {    
          //Month month;
          //month= date.getMonth();
          //return month;

          Calendar calendar = null;
          try{
          calendar = Calendar.getInstance(TimeZone.getDefault());         
          Date dateCurrent = calendar.getTime();
          //calendar.setTimeZone(TimeZone.getTimeZone("Europe/Amsterdam"));          
          currentDay =calendar.get(Calendar.DATE);
          if(currentDay < 10){currentDayString ="0" +currentDay;}
          else
          {currentDayString =  ""+currentDay;}          
          //System.out.println(showDayString);
          currentMonth = calendar.get(Calendar.MONTH)+1;
          if(currentMonth < 10){currentMonthString ="0" +currentMonth;}
          else
          {currentMonthString =  ""+currentMonth;}
          //System.out.println(showMonthString);
          currentYear = calendar.get(Calendar.YEAR);
          currentYearString =  ""+currentYear;
          //System.out.println(showYearString);
          toDay = LocalDate.of(currentYear,currentMonth,currentDay);
          //System.out.println("Month - " + String.format("%02d", (showMonth)));
          //System.out.println("Day - " + String.format("%02d", showDay));
          //System.out.println("Year - " + showYear);          
        }  catch (Exception e) {
            e.printStackTrace();}
          return toDay = LocalDate.of(currentYear,currentMonth,currentDay); 
        }      
   }
      
            
        
        
        
    
        