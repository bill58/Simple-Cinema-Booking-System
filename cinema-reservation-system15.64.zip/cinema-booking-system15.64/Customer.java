/**
 * A Class for Customer data.
 * 
 * @author Willem Hoogsteen
 * @version 1.1 2020.02.02
 */
public class Customer {
    // Customer's personal data.
    int customerId;
    String name;
    String surname;
    String street;
    int streetNumber;
    String postalCode;
    String town;
    String phoneNumber;    
    String cellPhoneNumber;
    String emailAddress;
    int age;
    String bankAccountNumber1;
    String bankAccountNumber2;
    /**
     * Customer customerId
     * @param customerid The id of a customer.
     */
    public Customer(int customerId)
    {
        this.customerId = customerId;
    }
    
    /**
     * Return the id of a customer.
     * @return The id number of a customer.
     */
    public int getId()
    {
        return customerId;
    }
    
    /**
     * Return the last name of a customer.
     * @return The lastname of a customer.
     */
    public String getSurName()
    {
        return surname ;
    }
    
    /**
     * Return the first name of a customer.
     * @return The firstname of a customer.
     */
    public String getName()
    {
        return name ;
    }
    
    /**
     * Return the streetname of a customer.
     * @return street The streetname of a customer address.
     */
    public String getStreetName()
    {
        return street;
    }
    
    /**
     * Return the streetnumber of a customer.
     * @return streetNumber The streetnumber of a customer address.
     */
    public int getStreetNumber()
    {
        return streetNumber;
    }
    
    /**
     * Return the postalcode of a customer.
     * @return postalCode The postalcode of a customer address.
     */
    public String getPostalCode()
    {
        return postalCode;
    }
    
    /**
     * Return the town of a customer.
     * @return town The Town of a customer address.
     */
    public String getTown()
    {
        return town;
    }
    
    /**
     * Return the fixed phoneNumber of a customer.
     * @return phoneNumber The phonenumber of a customer's address.
     */
    public String getFixedPhoneNumber()
    {
        return phoneNumber;
    }
    
    /**
     * Return the cell phonenumber of a customer.
     * @return cellPhoneNumber The cell phonenumber of a customer's address.
     */
    public String getCellPhoneNumber()
    {
        return cellPhoneNumber;
    }
    
    /**
     * Return the emailaddress of a customer.
     * @return emailAddress The email address of a customer.
     */
    public String getEmailAddress()
    {
        return emailAddress;
    }
    
    /**
     * Return the bankAccountNumber of a customer.
     * @param bankAccountNumber1 The bankaccountnumber of a customer.
     */
    public String getBankAccountNumber1()
    {
        return bankAccountNumber1;
    }
    
    /**
     * Return the bankAccountNumber of a customer.
     * @param bankAccountNumber2 The bankaccountnumber of a customer.
     */
    public String getBankAccountNumber2()
    {
        return bankAccountNumber2;
    }

    /**
     * Return the age of a customer.
     * @return age The age of a customer.
     */
    public int getAge()
    {
        return age;
    }
    
    /**
     * Set the first name of a customer.
     * @param name The first name of a customer.
     */
    public void setName(String name)
    {
        this.name = name;
    }
    
    /**
     * Set the lastname of a customer.
     * @param surName The lastname of a customer.
     */
    public void setSurname(String surname)
    {
        this.surname = surname;
    }
    
    /**
     * Set the streetname of a customer.
     * @param street The streetname of a customer address.
     */
    public void setStreet(String street)
    {
        this.street = street;
    }
    
    /**
     * Set the streetnumber of a customer.
     * @param streetNumber The streetnumber of a customer address.
     */
    public void setStreetNumber(int streetNumber)
    {
        this.streetNumber = streetNumber;
    }
    
    /**
     * Set the postalcode of a customer.
     * @param postalCode The postalcode of a customer address.
     */
    public void setPostalCode(String postalCode)
    {
        this.postalCode = postalCode;
    }
    
    /**
     * Set the town of a customer.
     * @param town The Town of a customer address.
     */
    public void setTown(String town)
    {
        this.town = town;
    }
    
    /**
     * Set the fixed phoneNumber of a customer.
     * @param phoneNumber The phonenumber of a customer's address.
     */
    public void setFixedPhoneNumber(String phoneNumber)
    {
        this.phoneNumber = phoneNumber;
    }
    
    /**
     * Set the cell phonenumber of a customer.
     * @param cellPhoneNumber The cell phonenumber of a customer's address.
     */
    public void setCellPhoneNumber(String cellPhoneNumber)
    {
        this.cellPhoneNumber = cellPhoneNumber;
    }
    
    /**
     * Set the emailaddress of a customer.
     * @param emailAddress The email address of a customer.
     */
    public void setEmailAddress(String emailAddress)
    {
        this.emailAddress = emailAddress;
    }
    
    /**
     * Set the bankAccountNumber of a customer.
     * @param bankAccountNumber1 The bankaccountnumber of a customer.
     */
    public void setBankAccountNumber1(String bankAccountNumber1)
    {
        this.bankAccountNumber1 = bankAccountNumber1;
    }
    
    /**
     * Set the bankAccountNumber of a customer.
     * @param bankAccountNumber2 The bankaccountnumber of a customer.
     */
    public void setBankAccountNumber2(String bankAccountNumber2)
    {
        this.bankAccountNumber2 = bankAccountNumber2;
    }
    
    /**
     * Set the age of a customer.
     * @param age The age of a customer.
     */
    public void setAge(int age)
    {
        this.age = age;
    }
    
    /**
     * Return a multi-line String containing the personal data of a customer.
     * @return the personal dadata of a customer. 
     */
    public String toString()
    
    {
        return customerId + "/n" + surname + " " + name + "/n" + street + " " + streetNumber + "/n"
        + postalCode + " " + town + "/n" + phoneNumber + "/n" + cellPhoneNumber + "/n" + emailAddress + "/n"
        + bankAccountNumber1 +"/n"+bankAccountNumber2+"/n"+age+"/n";
    }     
    
    /**
     * Show the Customer's address
     */ 
    public void printCustomer()
    {
        System.out.println(customerId);
        System.out.println(surname + " " + name);
        System.out.println(street + " " + streetNumber);
        System.out.println(postalCode + " " + town);
    }
}