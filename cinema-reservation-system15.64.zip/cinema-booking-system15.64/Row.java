import java.util.*;
/**
 * A Class for making rows with a rowClassNumber, seatCount and rowNumber
 * including an ArrayList for seats.
 * 
 * @author Willem Hoogsteen
 * @version 1.1 2020.02.02
 */
public class Row {  
    
        public ArrayList<Seat> seats;// collection of seats in a show shown in a theatre        
        private int rowNumber; // the rowNumber
        private int rowClass;// the class for price differentiation
        private int seatCount;// the seatnumber

    /**
     * Constructor
     * @param rowClass The rowclass
     * @param seatCount The seat
     * @param rowNumber The row
     */
    public Row (int rowClass, int seatCount, int rowNumber)
    {
        this.rowNumber = rowNumber;
        this.rowClass = rowClass;
        this.seatCount = seatCount;
        seats = new ArrayList<Seat>();
        createSeats(this.seatCount);
    }
    
    /**
     * sets the rowclass of the row
     * @param rowClass The rowclass of a row
     */
    public void setRowClass(int rowClass)
    {
        this.rowClass = rowClass;
    }
    
    /**
     * Return the rowClass of a row
     * @return rowClass The classnumber of the rowClass
     */
    public int getRowClass()
    {
        return this.rowClass;
    }
    
    /**
     * Return the rownumber
     * @return rowNumber The rownumber.
     */
    public int getRowNumber()
    {
        return rowNumber;
    }
    
    /**
	 * Create a Seat in the ArrayList seats
	 * @param seatCount The seatNumber to be created
	 */
	public void createSeats(int seatCount)
	{
		for (int i = 1; i <= seatCount; i++)
		{
			seats.add(new Seat(false, i));
		}
	}
    
    /**
	 * Return a  list of all the seats
	 * @return seats The seats in a show showing the movie
	 */
	public ArrayList<Seat> getSeats()
	{
		return seats;
	}
}