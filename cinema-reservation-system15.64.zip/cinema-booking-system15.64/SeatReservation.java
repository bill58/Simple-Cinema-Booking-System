/**
 * A class for making a booking for the Cinema.
 * The class can reserve/cancelreserved seats
 * 
 * @author Willem Hoogsteen
 * @version 1.1 2020.02.02
 */
public class SeatReservation {

    double cost;
    Customer customerx;
    private Show show;
    int rowNumber;
    int seatNumber;
    
    private SeatPlan seatPlan;
    /**
     * Constructor
     * @param Customer customer The customer.
     * @param Show show The show.
     */
    public SeatReservation(Customer customerx, SeatPlan seatPlan, Show show)
    {
        this.customerx = customerx;        
        this.seatPlan = seatPlan;
        this.show = show;
    }
    
    /**
     * return the price of a seat depending which rowclass.
     * @return cost The price of a single seat.
     */
    public double getCost()
    {
        if(show.getRows().get(rowNumber).getRowClass() == 1) {
            return cost += 8.29;
        }
        else {
            return cost += 5.30;
        }
    }
    
    /**
     * Set the rownumber.
     * @param rowNumber The rownumber to be set
     */
    public void setRowNumber(int rowNumber)
    {
        this.rowNumber = rowNumber;
    }
    
    /**
     * Set the seatnumber.
     * @param seatNumber The seatnumber to be set
     */
    public void setSeatNumber(int seatNumber)
    {
        this.seatNumber = seatNumber;
    }
    
    /**
     * return reservationstatus true to reserve a seat otherwise false if not possible.
     * @param selectedrow The row to select.
     * @param selectedseat The seat to select.
     * @return true means free for reservation, or false for not possible.
     */
    public boolean reserveSeat(int selectedRow, int selectedSeat)
    {
     
    if    (show.getRows().get(selectedRow).getSeats().get(selectedSeat).getReservationStatus())
        {       
            return false;
        }
        else {
            show.getRows().get(selectedRow).getSeats().get(selectedSeat).reserve();
            setRowNumber(selectedRow);
            setSeatNumber(selectedSeat);
            return true;
        }
    }
        
    /**
     * return true for setting free the seat reservation
     * @return true The seat is set free (unreserved)
     */
    public boolean unreserveSeat()
    {
        show.getRows().get(rowNumber).getSeats().get(seatNumber).unreserve();
        return true;
    }
        
    /**
     * return the customer.
     * @return customer The customer.
     */
    public Customer getCustomerX()
    {
        return customerx;
    }
}